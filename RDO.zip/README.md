Aplicação desenvolvida usando VS Code e Laravel
Quer experimentar? É muito simples
Crie uma pasta onde ficará o projeto no seu computador
Abra o VS Code, depois abra um terminal e clone o projeto para a pasta que criou
Vá no seu Gerenciador de Banco de Dados crie um novo banco e importe para ele o arquivo login.sql que está na pasta database do projeto que clonou
Volte no VS Code e altere o nome do arquivo .env.example para .env
No terminal do VS Conde, entre na pasta RDO e digite composer install
Depois de tudo instalado, digite php artisan serve
Pronto!