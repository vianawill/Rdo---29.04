

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2>Cadastrar Mão de Obra</h2>

        <form action="<?php echo e(route('mao_obras.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="funcao">Função do Trabalhador</label>
                <input type="text" class="form-control w-50" id="funcao" name="funcao" required>
            </div>

            <button type="submit" class="btn btn-primary">Cadastrar Mão de Obra</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\gjaco\Documents\Gabriel\Senac\Apps\RDO\resources\views/mao_obras/create.blade.php ENDPATH**/ ?>