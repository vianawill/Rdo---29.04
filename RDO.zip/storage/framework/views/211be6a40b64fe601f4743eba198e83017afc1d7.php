

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2>Cadastrar Equipamento</h2>

        <form action="<?php echo e(route('equipamentos.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="nome">Nome do Equipamento</label>
                <input type="text" class="form-control w-50" id="nome" name="nome" required>
            </div>

            <div class="form-group">
                <label for="tipo">Tipo de Equipamento</label>
                <input type="text" class="form-control w-50" id="tipo" name="tipo" required>
            </div>

            <button type="submit" class="btn btn-primary">Cadastrar Equipamento</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\gjaco\Documents\Gabriel\Senac\Apps\RDO\resources\views/equipamentos/create.blade.php ENDPATH**/ ?>