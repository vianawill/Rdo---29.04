

<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-4">
        <h1>Obras</h1>
        <a href="<?php echo e(route('obras.create')); ?>" class="btn btn-primary">Cadastrar Obra</a>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <table class="table table-striped">
        <thead>
            <tr>
                <th>Nome</th>
                <th>Empresa Contratada</th>
                <th>Objeto do Contrato</th>
                <th>Tempo Total do Contrato</th>
                <th>Data Prevista Início</th>
                <th>Data Real Início</th>
                <th>Data Prevista Término</th>
                <th>Data Real Término</th>
                <th>Descrição</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $obras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($obra->nome); ?></td>
                    <td><?php echo e($obra->empresa_contratada); ?></td>
                    <td><?php echo e($obra->objeto_contrato); ?></td>
                    <td><?php echo e($obra->tempo_total_contrato); ?></td>
                    <td><?php echo e($obra->data_prevista_inicio_obra); ?></td>
                    <td><?php echo e($obra->data_real_inicio_obra ?? 'N/A'); ?></td>
                    <td><?php echo e($obra->data_prevista_termino_obra); ?></td>
                    <td><?php echo e($obra->data_real_termino_obra ?? 'N/A'); ?></td>
                    
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('del-obra')): ?>
                        <td>
                            <a href="<?php echo e(route('obras.edit', $obra)); ?>" class="btn btn-warning">Editar</a>
                            <form action="<?php echo e(route('obras.destroy', $obra)); ?>" method="POST" style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger">Excluir</button>
                            </form>
                        </td>
                    <?php endif; ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\gjaco\Documents\Gabriel\Senac\Apps\RDO\resources\views/obras/index.blade.php ENDPATH**/ ?>