

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2>Cadastrar RDO</h2>

        <form action="<?php echo e(route('rdo.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="numero_rdo">Número do RDO</label>
                <input type="text" class="form-control" id="numero_rdo" name="numero_rdo" required>
            </div>

            <div class="form-group">
                <label for="data_atual">Data Atual</label>
                <input type="date" class="form-control" id="data_atual" name="data_atual" required>
            </div>

            <div class="form-group">
                <label for="obra_id">Obra</label>
                <select class="form-control" id="obra_id" name="obra_id" required>
                    <?php $__currentLoopData = $obras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($obra->id); ?>"><?php echo e($obra->objeto_contrato); ?> - <?php echo e($obra->empresa_contratada); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="form-group">
                <label for="dia_da_semana">Dia da Semana</label>
                <input type="text" class="form-control" id="dia_da_semana" name="dia_da_semana" required>
            </div>

            <div class="form-group">
                <label for="manha">Condição da Manhã</label>
                <select class="form-control" id="manha" name="manha" required>
                    <option value="Bom">Bom</option>
                    <option value="Chuva leve">Chuva leve</option>
                    <option value="Chuva forte">Chuva forte</option>
                </select>
            </div>

            <div class="form-group">
                <label for="tarde">Condição da Tarde</label>
                <select class="form-control" id="tarde" name="tarde" required>
                    <option value="Bom">Bom</option>
                    <option value="Chuva leve">Chuva leve</option>
                    <option value="Chuva forte">Chuva forte</option>
                </select>
            </div>

            <div class="form-group">
                <label for="noite">Condição da Noite</label>
                <select class="form-control" id="noite" name="noite" required>
                    <option value="Bom">Bom</option>
                    <option value="Chuva leve">Chuva leve</option>
                    <option value="Chuva forte">Chuva forte</option>
                </select>
            </div>

            <!-- Condição da Área -->
            <div class="form-group">
                <label for="condicao_area">Condição da Área</label>
                <select class="form-control" id="condicao_area" name="condicao_area" required>
                    <option value="Operável">Operável</option>
                    <option value="Operável parcialmente">Operável parcialmente</option>
                    <option value="Inoperável">Inoperável</option>
                </select>
            </div>

            <!-- Acidente -->
            <div class="form-group">
                <label for="acidente">Acidente</label>
                <select class="form-control" id="acidente" name="acidente" required>
                    <option value="Nao houve">Não houve</option>
                    <option value="Sem afastamento">Sem afastamento</option>
                    <option value="Com afastamento">Com afastamento</option>
                </select>
            </div>

           <!-- Equipamentos Utilizados (Select com múltiplas opções) -->
           <div class="form-group">
                <label for="equipamentos">Equipamentos Utilizados</label>
                <select class="form-control" id="equipamentos" name="equipamentos[]" multiple required>
                    <?php $__currentLoopData = $equipamentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equipamento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($equipamento->id); ?>"><?php echo e($equipamento->nome); ?> - <?php echo e($equipamento->tipo); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <small class="form-text text-muted">Selecione os equipamentos utilizados (mantenha pressionado Ctrl ou Cmd para selecionar múltiplos).</small>
            </div>

            <!-- Mão de Obra Utilizada (Select com múltiplas opções) -->
            <div class="form-group">
                <label for="mao_obras">Mão de Obra Utilizada</label>
                <select class="form-control" id="mao_obras" name="mao_obras[]" multiple required>
                    <?php $__currentLoopData = $mao_obras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mao_obra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($mao_obra->id); ?>"><?php echo e($mao_obra->funcao); ?> - Quantidade: <?php echo e($mao_obra->quantidade); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <small class="form-text text-muted">Selecione a mão de obra utilizada (mantenha pressionado Ctrl ou Cmd para selecionar múltiplos).</small>
            </div>
            
            <button type="submit" class="btn btn-primary">Cadastrar RDO</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\gjaco\Documents\Gabriel\Senac\Apps\RDO\resources\views/rdo/create.blade.php ENDPATH**/ ?>